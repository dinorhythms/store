import React, { Component } from 'react'

export default class Product extends Component {
  render() {
    return (
      <div>
        <h3>Hello fro Product</h3>
      </div>
    )
  }
}
